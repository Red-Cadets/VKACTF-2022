import os

from quart import Quart, render_template

app = Quart(__name__)

@app.route('/')
async def index():
    return await render_template('index.html')

@app.route('/flag')
async def flag():
    return os.getenv('FLAG', 'vka{fake}')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)