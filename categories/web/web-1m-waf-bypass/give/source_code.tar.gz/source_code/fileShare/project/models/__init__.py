from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import validates

db = SQLAlchemy()


class Users(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(128), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    token = db.Column(db.String(128), unique=True, nullable=False)

    def is_active(self):
        return True

    def get_id(self):
        return self.username

    def is_authenticated(self):
        return True

    def is_anonymous(self):
        return False

    def __repr__(self):
        return '<users %r>' % self.id
    
class Active(db.Model):
    __tablename__ = "active"

    id = db.Column(db.Integer, primary_key=True)
    usershare = db.Column(db.String(128), nullable=False)
    usercollect = db.Column(db.String(128), nullable=False)
    