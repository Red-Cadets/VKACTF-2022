import re

from project.models import Active


ALLOWED_EXTENSIONS =  {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'py', 'gif', 'csv'}
BLACK_LIST = ["/", "#", "!", "@", ";", '"', "'"]


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def check_file(req, error=None):
    if 'file' not in req.files:
        error = 'Файл не обнаружен'

    file = req.files['file']
    if file.filename == '':
        error = 'Пустой файл'
    if not allowed_file(file.filename):
        error = 'Недопустимое расширение'
    return file, error

def validator(name):
    for element in BLACK_LIST:
        if re.match(rf".*{element}.*", name):
            return None, "Обнаружен запрещенный символ"
    if ".." in name: return None, "Обнаружен запрещенный символ!"   # <- DETECT LFI
    
    return name.strip(), None
    
def check_download(path):
    path, error = validator(path)
    return path, error

def check_share_download(req, username):
    usershare = req.form.get('usershare')
    filename = req.form.get('filename')

    if not usershare: return None, None, "Укажите имя пользователя."
    if not filename:  return None, None, "Укажите название файла."
    if not Active.query.filter_by(usershare=usershare, usercollect=username).first():
        return None, None, "Чтение файла запрещено"

    filename, error = validator(filename)

    return usershare, filename, error