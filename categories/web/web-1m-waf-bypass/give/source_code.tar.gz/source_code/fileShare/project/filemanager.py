from flask import (
    redirect,
    request,
    url_for,
    session,
    send_file, 
    flash
)

from flask_login import login_required
from werkzeug.utils import secure_filename

from os.path import join

from project import app

from project.utils.file import (
    check_file,
    check_download, 
    check_share_download
)

@app.route('/upload', methods = ['POST'])
@login_required
def upload(error=None):
    username = session.get("username")
    
    flashType = "danger"
    if request.method == 'POST':
        file, error = check_file(request)   
        if not error:
            filename = secure_filename(file.filename)
            file.save(
                    join(app.root_path,
                         app.config['UPLOAD_FOLDER'], 
                         username, 
                         filename
                        )
                    )
            error = "Файл успешно загружен!"
            flashType = "success"

    flash(error, flashType)
    return redirect(
        url_for('profile')
    )


@app.route('/download/<filename>')
@login_required
def download(filename, error=None):
    username = session.get("username")
    
    filename, error = check_download(filename)
    if not error:
        path = join(app.config['UPLOAD_FOLDER'], 
                    username, 
                    filename
                )
        try:
            return send_file(path)
        except:
            error = "Такого файла не существует"
            
    flash(error, "danger")
    return redirect(
            url_for('profile')
        )

@app.route('/share', methods = ['POST'])
@login_required
def share(error=None):
    username = session.get("username")
    usershare, filename, error = check_share_download(request, username)
    
    if not error:
        path = join(app.config['UPLOAD_FOLDER'],
                    usershare,
                    filename
                )     
        try:
            return send_file(path)
        except:
            error = "Такого файла не существует"
    
    flash(error, "danger")
    return redirect(
            url_for('profile')
        )