import os

basedir = os.path.abspath(os.path.dirname(__file__))

class Config(object):
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///dev.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = "files"
    MAX_CONTENT_LENGTH = 1024 * 1024 * 2 # 2Mb

    STATIC_FOLDER = f"{os.getenv('APP_FOLDER')}/project/static"
    
    SECRET_KEY = "test_secret_key_for_development"