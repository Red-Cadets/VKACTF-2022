from flask import Flask

from flask_login import LoginManager

from project.models import db

app = Flask(__name__)
app.config.from_object("project.config.Config")

login_manager = LoginManager()
login_manager.init_app(app)

db.init_app(app)

from project import user, filemanager