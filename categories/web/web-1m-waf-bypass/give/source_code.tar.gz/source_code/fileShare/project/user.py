from flask import (
    redirect,
    render_template,
    request,
    url_for,
    session,
    flash
)

from flask_login import login_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from secrets import token_urlsafe

import pathlib

from project.utils.user import (
    check_input,
    check_token, 
    list_files, 
    check_input_register
)

from project.models import Users, Active

from project import app, db

@app.route('/')
def index():
    return redirect(
            url_for("login")
        )

@app.route('/login', methods=['GET', 'POST'])
def login(error=None):
    user = session.get("username")
    
    if user:
        return redirect(
            url_for("profile"),
        )

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        err = check_input(username, password)
        if err: 
            flash(err, "danger")
            return render_template("login.html")

        user = Users.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            session["username"] = username
            login_user(user)
            return redirect(
                    url_for("profile")
                )
        else:
            error = 'Неверные имя пользователя или пароль.'

    flash(error, "danger")
    return render_template("login.html")


@app.route('/register', methods=['GET', 'POST'])
def register(error=None):
    user = session.get("username")
    
    if user:
        return redirect(
            url_for("login"),
        )

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        password_repeat = request.form.get("passwordrepeat")
        
        err = check_input_register(username, password, password_repeat)
        if err: 
            flash(err, "danger")
            return render_template("register.html")

        user = Users.query.filter_by(username=username).first()

        if user:
            flash("Имя пользователя уже существует.", "danger")
            return render_template("register.html")

        else:
            user = Users(
                username=username,
                password = generate_password_hash(password),
                token = token_urlsafe(32)
            )
            try:
                db.session.add(user)
                db.session.flush()
                db.session.commit()
                
                user = Users.query.filter_by(username=username).first()

                session["username"] = username
                login_user(user)

                pathlib.Path(app.root_path, app.config['UPLOAD_FOLDER'], username).mkdir(exist_ok=True)
                
                flash("Пользователь успешно зарегестрирован!", "success")
                return redirect(
                        url_for("profile")
                    )
            
            except:
                db.session.rollback()
                print("[-] Ошибка добавления в БД")
                error = "Ошибка добавления в БД. Свяжитесь с администратором."

    flash(error, "danger")
    return render_template(
        "register.html",
        user=user,
    )

@app.route('/profile')
@login_required
def profile():
    username = session.get("username")
    
    user = Users.query.filter_by(username=username).first()
    files = list_files(username)

    return render_template(
        "profile.html",
        user=user,
        files=files
    )

@app.route('/activate', methods=['POST'])
@login_required
def activate(error=None):
    flashType="danger"
    username = session.get("username")
    user = Users.query.filter_by(username=username).first()

    usershare, error = check_token(request, username)

    if not error: 
        token_active=Active(
            usershare = usershare.username,
            usercollect = username
        )
        try:
            db.session.add(token_active)
            db.session.flush()
            db.session.commit()

            error = "Токен успешно активирован"
            flashType="success"
        except:
            db.session.rollback()
            print("[-] Ошибка добавления в БД")
            error = "Ошибка добавления в БД. Свяжитесь с администратором."

    flash(error, flashType)
    return redirect(
            url_for("profile")
        )

@app.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect(
            url_for('login')
        )

