from flask import redirect, url_for, flash

from os import listdir
from os.path import isfile, join


from project import app, login_manager 

from project.models import Users, Active


def check_input(username, password):
    if not username: return "Укажите имя пользователя."
    if not password: return "Укажите пароль."    
    else: return False

def check_input_register(username, password, password_repeat):
    if not username: return "Укажите имя пользователя."
    if not password: return "Укажите пароль."
    if not password: return "Повторите пароль."
    if password != password_repeat: return "Пароли не совпадают."
    if not username.isalpha(): return "Используйте для логина только буквы"
    else:            return False

def check_token(req, username):
    token = req.form.get('token')
    if not token: 
        return None, "Укажите токен пользователя."
    usershare = Users.query.filter_by(token=token).first()
    if usershare:
        if usershare.username == username:
            return None, "Используйте не свой токен"
        
        checkUses = Active.query.filter_by(usershare=usershare.username, usercollect=username).first()
        if checkUses:
            return None, "Вы уже активировали этот токен"

        return usershare, None
    else:
        return None, "Токен не валидный"

def list_files(username):
    path = join(app.root_path, app.config['UPLOAD_FOLDER'], username)
    files = [f for f in listdir(path) if isfile(join(path, f))]
    return  files

@login_manager.user_loader
def load_user(username):
    return Users.query.filter(Users.username == username).first()

@login_manager.unauthorized_handler
def unauthorized():
    flash('Вы не можете посетить страницу, введите логин и пароль', "danger")
    return redirect(url_for('login'))