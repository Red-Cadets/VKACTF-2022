
from flask.cli import FlaskGroup

import os
from secrets import token_urlsafe
from werkzeug.security import generate_password_hash

from project import app
from project.models import db, Users


cli = FlaskGroup(app)


@cli.command("create_db")
def create_db():
    db.drop_all()
    db.create_all()
    db.session.commit()

    db.session.add(Users(
                username="admin",
                password = generate_password_hash(os.urandom(16).hex()),
                token = token_urlsafe(32)
                )
            )
    db.session.flush()
    db.session.commit()

    print("[+] Successfully created db")

if __name__ == "__main__":
    cli()