#!/usr/bin/env python3

import os
import sys
import signal

def signal_handler(sig, frame):
    sys.exit(0)

MONSTERS = [
    {
        "monster_id": 1,
        "name": 'Сѣрый волкъ',
        "strength": 15,
        'reward': 150
    },
    {
        "monster_id": 2,
        "name": 'Матёрый волкъ',
        "strength": 45,
        'reward': 200
    },
    {
        "monster_id": 3,
        "name": 'Железный волкъ',
        "strength": 110,
        'reward': 350
    },
    {
        "monster_id": 4,
        "name": 'Киберволкъ',
        "strength": 1500,
        'reward': '🗝️'
    }
]

WEAPONS = [
        {
        "weapon_id": 1,
        "name": 'Пепелъ изъ рябины',
        "damage": "20",
        "cost": 50
    },
    {
        "weapon_id": 2,
        "name": 'Осиновый колъ',
        "damage": "50",
        "cost": 100
    },
    {
        "weapon_id": 3,
        "name": 'Серебряный мечъ',
        "damage": "75",
        "cost": 150
    },
    {
        "weapon_id": 4,
        "name": 'Цвѣтокъ растенія омелы',
        "damage": "150",
        "cost": 300
    },
    {
        "weapon_id": 5,
        "name": 'Волчій аконитъ',
        "damage": "200",
        "cost": 600
    }
]

class Game():
    def __init__(self):
        self.balance = 100
        self.inventory = []

        self.WEAPONS = WEAPONS
        self.MONSTERS = MONSTERS
        self.KEY = False
        self.CUSTOM_WEAPON = False
        
        self.START()
    
    def START(self):
        os.system('clear')
        os.system('echo "$(cat banners/welcome.txt)"')
    
    def MENU(self):
        os.system('clear')
        os.system('echo "$(cat banners/menu.txt)"')

    def INVENTORY(self):
        print("⚔️  == Ваш инвентарь == ⚔️\n".center(100))
        for weapon in self.inventory:
            print(f'- {weapon["name"]} - {weapon["damage"]}'.center(100))

    def BALANCE(self):
        print("💸 == Ваш балансъ == 💸\n".center(100))
        print(f'{self.balance} Червонцевъ'.center(100))
    
    def BUY_WEAPON(self):
        print("🧺 == Лавка == 🧺\n".center(100))
        print("Что вы хотите пріобрѣсти?\n".center(100))
        for weapon in self.WEAPONS:
            print(f'{weapon["weapon_id"]}. {weapon["name"]}'.center(100))
            print(f'💸 Стоимость - {weapon["cost"]}'.center(100))
            print(f' 🏹 Урон - {weapon["damage"]}\n'.center(100))

        try:
            weapon_id = int(input("\n\tВыберите оружие> "))
        except ValueError:
            print("Оружие не найдено!".center(100))
            return

        try:
            weapon = next(weapon for weapon in self.WEAPONS if weapon["weapon_id"] == weapon_id)
        except StopIteration:
            print("Оружие не найдено!".center(100))
            return


        if self.balance < weapon["cost"]:
            print("У васъ недостаточно червонцевъ!".center(100))
            return

        self.balance -= weapon["cost"]
        self.inventory.append(weapon)

        del self.WEAPONS[WEAPONS.index(weapon)]
        print("Вы успешно приобрели оружие".center(100))

    def FIGHT(self):
        print("👹 == Бой с монстрами == 👹\n".center(100))
        print("Съ кѣмъ вы хотите сразиться?\n".center(100))
        for monster in self.MONSTERS:
            print(f'{monster["monster_id"]}. {monster["name"]}'.center(100))
            print(f'💪 Сила - {monster["strength"]}'.center(100))
            print(f'💸 Награда за голову - {monster["reward"]}\n'.center(100))
        
        try:
            monster_id = int(input("\n\tВыберите монстра> "))
        except ValueError:
            print("Монстръ не найденъ!".center(100))
            return

        try:
            monster = next(monster for monster in self.MONSTERS if monster["monster_id"] == monster_id)
        except StopIteration:
            print("Монстръ не найденъ!".center(100))
            return

        user_strength = sum([ float(weapon["damage"]) for weapon in self.inventory ])
        if user_strength < monster["strength"]:
            print("Вамъ не хватило силы. Вы были убиты ☠️\n".center(100))
            exit()

        if monster["reward"] == '🗝️':
            self.KEY = True
        else:
            self.balance += monster["reward"]

        del self.MONSTERS[MONSTERS.index(monster)]
        print(f'Вы успешно одолѣли монстра!'.center(100))

    def CREATE_WEAPON(self):
        print("⚙️  == Создать своё оружіе == ⚙️\n".center(100))
        print("Созданіе своего оружія стоитъ 150 червонцевъ\n".center(100))
        if self.balance < 150:
            print("У васъ недостаточно червонцевъ".center(100))
            return

        if self.CUSTOM_WEAPON:
            print("Создать свое оружіе можно единожды!".center(100))
            return

        print("Введите названіе оружія".center(100))
        weapon_name = input("\n\tНазвание оружия> ")

        print("Введите уронъ оружія".center(100))
        weapon_damage = input("\n\tУронъ оружия (XXX)> ")

        if len(weapon_damage) > 3:
            print("Навыковъ кузнеца недостаточно для созданія оружія съ такимъ урономъ".center(100))
            return

        self.inventory.append({
            "weapon_id": len(WEAPONS),
            "name": weapon_name,
            "damage": weapon_damage
        })

        self.balance -= 150
        self.CUSTOM_WEAPON = True
        print("Вы успѣшно создали свое оружіе".center(100))
    
    def GET_FLAG(self):
        print("🗝️  == Открыть сундукъ съ сокровищемъ == 🗝️\n".center(100))
        if self.KEY:
            with open('flag.txt', 'r') as file:
                FLAG = file.read()
            print(FLAG.center(100), end="\n\n")
            exit()
        else:
            print("Чтобы открыть сундукъ вамъ нуженъ 🗝️  ключъ".center(100))

    def USER_INPUT(self):
        choice = input('\n\t#> ')
        match choice:
            case "0":
                self.MENU()
            case "1":
                self.INVENTORY()
            case "2":
                self.BALANCE()
            case "3":
                self.BUY_WEAPON()
            case "4":
                self.CREATE_WEAPON()
            case "5":
                self.FIGHT()
            case "6":
                self.GET_FLAG()
            case _:
                print("Некорректный вводъ!".center(100))

def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGALRM, signal_handler)

    game = Game()
    while True:
        try:
            signal.alarm(30)
            game.USER_INPUT()
        except:
            sys.exit(0)

if __name__ == '__main__':
    main()

